/** Automatically generated file. DO NOT MODIFY */
package se.cfor.truckdriver;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}