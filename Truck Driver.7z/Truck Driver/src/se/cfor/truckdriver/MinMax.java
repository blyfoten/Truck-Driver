package se.cfor.truckdriver;

public class MinMax {
	public float min;
	public float max;
}
